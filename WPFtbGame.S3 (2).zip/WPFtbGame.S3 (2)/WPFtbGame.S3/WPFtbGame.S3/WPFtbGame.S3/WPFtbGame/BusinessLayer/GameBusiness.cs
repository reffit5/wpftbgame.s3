﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFtbGame.Models;
using WPFtbGame.DataLayer;
using WPFtbGame.PresentationLayer;
using System.Collections.ObjectModel;

namespace WPFtbGame.BusinessLayer
{
    public class GameBusiness
    {
        //Map _gameMap;
        //GameMapCoorinates _currentLocation;
        GameSessionViewModel _gameSessionViewModel;
        Player _player = new Player();
        //List<string> _messages;
        bool _newPlayer = false;
        PlayerSetupView _playerSetupView = null;

        private void SetupPlayer()
        {
            if (_newPlayer)
            {
                _playerSetupView = new PlayerSetupView(_player);
                _playerSetupView.ShowDialog();



                _player.Health = 100;
                _player.Lives = 1;
            }
            else
            {
                _player = GameData.PlayerData();
            }
        }

        public GameBusiness()
        {
            SetupPlayer();
            InitializeDataSet();
            InitializeAndShowView();
        }

        

        private void InitializeDataSet()
        {
            _player = GameData.PlayerData();
            //_gameMap = GameData.GameMap();
            //_currentLocation = GameData.InitialGameMapLocation();
            //_messages = GameData.InitalizeMessage();
        }

        private void InitializeAndShowView()
        {
            _gameSessionViewModel = new GameSessionViewModel(
                _player,
                GameData.GameMap(),
                GameData.InitialGameMapLocation()
                
                );

            GameSessionView gameSessionView = new GameSessionView(_gameSessionViewModel);

            gameSessionView.DataContext = _gameSessionViewModel;

            gameSessionView.Show();


            //_playerSetupView.Close();
        }
    }
}
