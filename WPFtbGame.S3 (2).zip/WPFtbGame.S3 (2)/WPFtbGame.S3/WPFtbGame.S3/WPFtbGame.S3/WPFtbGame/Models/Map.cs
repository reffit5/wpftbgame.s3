﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace WPFtbGame.Models
{
    public class Map
    {
        #region FIELDS
        private Location[,] _mapLocations;
        private GameMapCoorinates _currentLocationCordinates;
        private int _maxRows, _maxColumns;
        private List<GameItem> _standardGameItems;



        #endregion

        #region PROPERTIES
        public Location[,] MapLocation
        {
            get { return _mapLocations; }
            set { _mapLocations = value; }
        }

        public GameMapCoorinates CurrentLocationCordinates
        {
            get { return _currentLocationCordinates; }
            set { _currentLocationCordinates = value; }
        }

        public Location CurrentLocation
        {
            get { return _mapLocations[_currentLocationCordinates.Row, _currentLocationCordinates.Column]; }
        }

        public List<GameItem> StandardGameItems
        {
            get { return _standardGameItems; }
            set { _standardGameItems = value; }
        }

       

        #endregion

        #region CONSTRUCTORS


        public Map(int rows, int columns)
        {
            _maxRows = rows;
            _maxColumns = columns;
            _mapLocations = new Location[rows, columns];
        }

        #endregion

        #region METHODS

        #region MOVEMENT METHODS

        public void MoveNorth()
        {
            if (_currentLocationCordinates.Row > 0)
            {
                _currentLocationCordinates.Row -= 1;
            }


        }

        public void MoveEast()
        {
            if (_currentLocationCordinates.Column < _maxColumns - 1)
            {
                _currentLocationCordinates.Column += 1;
            }
        }

        public void MoveSouth()
        {
            if (_currentLocationCordinates.Row < _maxRows - 1)
            {
                _currentLocationCordinates.Row += 1;
            }
        }

        public void MoveWest()
        {
            if (_currentLocationCordinates.Column > 0)
            {
                _currentLocationCordinates.Column -= 1;
            }
        }

        public Location NorthLocation()
        {
            Location northLocation = null;
            if (_currentLocationCordinates.Row > 0)
            {
                Location nextNorthLocation = _mapLocations[_currentLocationCordinates.Row - 1, _currentLocationCordinates.Column];
                if (nextNorthLocation != null)
                {
                    northLocation = nextNorthLocation;
                }
            }
            return northLocation;
        }

        public Location EastLocation()
        {
            Location eastLocation = null;
            if (_currentLocationCordinates.Column < _maxColumns - 1)
            {
                Location nextEastLocation = _mapLocations[_currentLocationCordinates.Row, _currentLocationCordinates.Column + 1];
                if (nextEastLocation != null)
                {
                    eastLocation = nextEastLocation;
                }
            }

            return eastLocation;
        }

        public Location SouthLocation()
        {
            Location southLocation = null;
            if (_currentLocationCordinates.Row < _maxRows - 1)
            {
                Location nextSouthLocation = _mapLocations[_currentLocationCordinates.Row + 1, _currentLocationCordinates.Column];
                if (nextSouthLocation != null)
                {
                    southLocation = nextSouthLocation;
                }
            }

            return southLocation;
        }
        public Location WestLocation()
        {
            Location westLocation = null;
            if (_currentLocationCordinates.Column > 0)
            {
                Location nextWestLocation = _mapLocations[_currentLocationCordinates.Row, _currentLocationCordinates.Column - 1];
                if (nextWestLocation != null)
                {
                    westLocation = nextWestLocation;
                }
            }

            return westLocation;
        }
        #endregion

        #region ACTION METHODS
        /// <param name="relicId"></param>
        /// <returns>user message regarding success of attempt</returns>
        public string OpenLocationsByRelic(int relicId)
        {
            string message = "The relic did nothing.";
            Location mapLocation = new Location();

            for (int row = 0; row < _maxRows; row++)
            {
                for (int column = 0; column < _maxColumns; column++)
                {
                    mapLocation = _mapLocations[row, column];

                    if (mapLocation != null && mapLocation.RequiredRelicId == relicId)
                    {
                        mapLocation.Accessible = true;
                        message = $"{mapLocation.Name} is now accessible.";
                    }
                }
            }

            return message;
        }

        #endregion

        #endregion
    }
}
        
