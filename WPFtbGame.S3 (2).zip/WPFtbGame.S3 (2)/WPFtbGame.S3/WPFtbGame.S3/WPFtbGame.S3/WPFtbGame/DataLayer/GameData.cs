﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using WPFtbGame.Models;

namespace WPFtbGame.DataLayer
{
    public static class GameData
    {

        public static Player PlayerData()
        {
            return new Player()
            {
                Id = 1,
                DogName = "Alfred",
                Age = 12,
                Health = 100,
                Lives = 1,
                typeOfDog = Character.TypeOfDog.Doxin,
                DogImage = "dog.jpg",
                LocationId = 1,
                Inventory = new ObservableCollection<GameItem>()
                {
                    GameItemById(1002),
                    GameItemById(2002)
                }

            };
        }

        private static GameItem GameItemById(int id)
        {
            return StandardGameItems().FirstOrDefault(i => i.Id == id);
        }

        public static List<string> InitalizeMessage()
        {
            return new List<string>()
            {
                "You are Lost in the park and need to find your way back home."
        };
        }

        public static GameMapCoorinates InitialGameMapLocation()
        {
            return new GameMapCoorinates() { Row = 0, Column = 0 };
        }

        public static Map GameMap()
        {
            int rows = 3;
            int columns = 4;

            Map gameMap = new Map(rows, columns);

            gameMap.StandardGameItems = StandardGameItems();

            gameMap.MapLocation[0, 0] = new Location()
            {
                Id = 1,
                Name = "The Dog Park",
                Description = "This is a park for dogs and your owner left you here." +
                "You need to find your way back to the Penthouse form this location.  " +
                "There are alot of trees and alot of noise.",
                Accessible = true,
                Message = "There are some strange people trying to look for your owner You break away where do you start running.",
                GameItems = new ObservableCollection<GameItem>()
                {
                    GameItemById(2001)
                }
            };
            gameMap.MapLocation[0, 1] = new Location()
            {
                Id = 2,
                Name = "Wild West Buchery",
                Description = " This is a very historic bucher shop  animals will often go missing around this area" +
                "be careful not to turn into sausage." +
                "There is alot of smoke in this area and it takes 15 points off of your health.",
                Accessible = true,
                Message = "The Butcher Runs outside at you with a big knife.  What will you do.",
                ModifyHealth = -15,
                GameItems = new ObservableCollection<GameItem>
                {
                    GameItemById(4002)
                }
            };

            gameMap.MapLocation[1, 1] = new Location()
            {
                Id = 3,
                Name = "New Yourk Pound",
                Description = "Your Master has often threatend to send you to this place." +
                "You are uncomfortable around this building because you can hear sad dogs barking in the building." +
                "There is a trap outside that takes 5 points away from your helth.",
                Message = "A Dangerous man has a srynge full of dog poison.  " +
                "What are you going to do next.",
                Accessible = true,
                ModifyHealth = -5
                
            };

            gameMap.MapLocation[1, 2] = new Location()
            {
                Id = 4,
                Name = "PetsMart",
                Description = "They love animals at this place they give you a free life because you chose to visit them ",
                Accessible = false,
                Message = "Animals love this place.  Its the closest place to heven for you.",
                ModifyHealth = +50,
                ModifyLives = +1,
                RequiredRelicId = 2001,
                GameItems = new ObservableCollection<GameItem>
                {
                    GameItemById(3001),
                    GameItemById(2003)
                    
                }

            };

            gameMap.MapLocation[2, 0] = new Location()
            {
                Id = 5,
                Name = "Marshas House",
                Description = "Marsha is a friendly person but she doesnt realize that it is not nice to take someones dog" +
                " look out she might try to keep you for herself and dress you up",
                Accessible = true,
                ModifyLives = +1,
                Message = "Marsha is kinda crazy .",
                ModifyHealth = 5,
                GameItems = new ObservableCollection<GameItem>
                {
                    GameItemById(4001)
                }

            };
            gameMap.MapLocation[2, 1] = new Location()
            {
                Id = 6,
                Name = "The Penthouse",
                Description = "This is your owners house",
                Accessible = true,
                RequiredRelicId = 4001,
                Message = "Your owner is waiting for you and is super happy to see you." +
                "You realize your owner is kinda dumb for just waiting for you to come home rather than looking for you."
                
            };

            return gameMap;
        }

        public static List<GameItem> StandardGameItems()
        {
            return new List<GameItem>()
            {
                new Weapon(1001, "Dog Bone", 75, 1, 4, "This is a short and fast bone.  You can use it as a club to damamge enimies in certian areas.", 10),
                new Weapon(1002, "Leash", 250, 1, 9, "This weapon can be used to whip the enimies you can also tie them up if you dont want to damage them.", 10),
                new Relic(2001, "Gold Coin", 10, " gold coin probubly not usful becaus you are a dog", 1, "You have opened the PetSmart.", Relic.UseActionType.OPENLOCATION ),
                new Drinks(2002, "Water", 5, 10, 1, "A common drink for your kind.", 1),
                new Weapon(2003, "Knife", 45, 1, 5, "Used to cut things.  Good thing you can bite on the handel", 5),
                new Drinks(3001, "Beer", 5, 40, 1, "This Messes you up but not in the worst way.", 5),
                new Relic(4001, "Hall pass", 5, "Used in americna highschools because you cant trust teens.", 5, "You have opened the Pent House.", Relic.UseActionType.OPENLOCATION),
                new Relic(4002, "Rat Poison", 5, "I wonder what would happen if I ate this", 5, "You get very sick and die because the box said poison.", Relic.UseActionType.KILLPLAYER)
            };
        }

    }
    }

